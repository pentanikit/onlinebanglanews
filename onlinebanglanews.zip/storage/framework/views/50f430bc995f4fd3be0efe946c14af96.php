
<?php $__env->startSection('pages'); ?>
    <!-- Page Title -->
    <div class="container">
        <div class="page-title-wrap">
            <h2><?php echo e($category->name); ?></h2>
            <p>সাম্প্রতিক সব <?php echo e($category->name); ?> খবর একসাথে</p>
        </div>
    </div>

    <?php if($posts->isNotEmpty()): ?>
        <?php
            $lead = $posts->first(); // প্রথম নিউজ

            $others = $posts->skip(1); // বাকি সব নিউজ
        ?>


        <!-- Main Layout -->
        <div class="container main-layout">
            <main class="content">
                <!-- Featured of this category -->
                <article class="lead-news">
                    <img src="<?php echo e(asset('storage') . '/' . $lead->featuredImage->file_path); ?>" alt="">
                    <h2><?php echo e($lead->title); ?></h2>
                    <p class="meta"><?php echo e($lead->author->name); ?> | ১১ নভেম্বর ২০২৫</p>
                    <p class="excerpt">
                        <?php echo e($lead->excerpt); ?>

                    </p>
                </article>

                <!-- Category listing -->
                <div class="category-list">

                    <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="cat-item">
                            <h3><a href="<?php echo e(route('singleNews', $item->slug)); ?>"><?php echo e($item->title); ?></a></h3>
                            <p class="meta"><?php echo e($item->author->name); ?> | ১১ নভেম্বর ২০২৫</p>
                            <p><?php echo e($item->excerpt); ?></p>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination (dummy) -->
                <div class="pagination">
                    <a href="#" class="active">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">পরের পাতা »</a>
                </div>
            </main>

            <!-- Sidebar -->
            <aside class="sidebar">
                <?php if (isset($component)) { $__componentOriginal1694038806aa1acdffca9de32f4d7a2a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1694038806aa1acdffca9de32f4d7a2a = $attributes; } ?>
<?php $component = App\View\Components\Frontend\LatestNews::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.latest-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\LatestNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1694038806aa1acdffca9de32f4d7a2a)): ?>
<?php $attributes = $__attributesOriginal1694038806aa1acdffca9de32f4d7a2a; ?>
<?php unset($__attributesOriginal1694038806aa1acdffca9de32f4d7a2a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1694038806aa1acdffca9de32f4d7a2a)): ?>
<?php $component = $__componentOriginal1694038806aa1acdffca9de32f4d7a2a; ?>
<?php unset($__componentOriginal1694038806aa1acdffca9de32f4d7a2a); ?>
<?php endif; ?>
                <div class="widget ad-widget">
                    <span>300x250 AD</span>
                </div>
            </aside>
        </div>
    <?php else: ?>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/frontend/categorywisenews.blade.php ENDPATH**/ ?>