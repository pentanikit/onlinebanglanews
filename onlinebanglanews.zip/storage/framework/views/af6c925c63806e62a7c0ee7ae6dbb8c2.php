<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <title>বাংলা সংবাদপত্র</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <!-- Google Font (optional) --
    >
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Top Bar -->
  <div class="topbar">
    <div class="container topbar-inner">
      <div class="top-left">
        মঙ্গলবার, ১১ নভেম্বর ২০২৫ | ঢাকা
      </div>
      <div class="top-right">
        <a href="#">আজকের পত্রিকা</a>
        <a href="#">ই-পেপার</a>
        <a href="#">যোগাযোগ</a>
      </div>
    </div>
  </div>
    <!-- Header -->
  <?php if (isset($component)) { $__componentOriginalf82169ef8884f6cd7417452259267c67 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf82169ef8884f6cd7417452259267c67 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf82169ef8884f6cd7417452259267c67)): ?>
<?php $attributes = $__attributesOriginalf82169ef8884f6cd7417452259267c67; ?>
<?php unset($__attributesOriginalf82169ef8884f6cd7417452259267c67); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf82169ef8884f6cd7417452259267c67)): ?>
<?php $component = $__componentOriginalf82169ef8884f6cd7417452259267c67; ?>
<?php unset($__componentOriginalf82169ef8884f6cd7417452259267c67); ?>
<?php endif; ?>
    <!-- Nav -->
  <?php if (isset($component)) { $__componentOriginal0d201bafb612be34a742a97f6a37dad0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d201bafb612be34a742a97f6a37dad0 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Navigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d201bafb612be34a742a97f6a37dad0)): ?>
<?php $attributes = $__attributesOriginal0d201bafb612be34a742a97f6a37dad0; ?>
<?php unset($__attributesOriginal0d201bafb612be34a742a97f6a37dad0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d201bafb612be34a742a97f6a37dad0)): ?>
<?php $component = $__componentOriginal0d201bafb612be34a742a97f6a37dad0; ?>
<?php unset($__componentOriginal0d201bafb612be34a742a97f6a37dad0); ?>
<?php endif; ?>

  <?php echo $__env->yieldContent('pages'); ?>

    <!-- Footer -->
  <footer class="footer">
    <div class="container footer-inner">
      <p>© ২০২৫ দৈনিক সময়বার্তা | সম্পাদক ও প্রকাশক: এমদাদুল হক (ডেমো)</p>
      <p>কারিগরি সহায়তায়: Pentanik IT</p>
    </div>
  </footer>
</body>
</html><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/frontend/layout.blade.php ENDPATH**/ ?>