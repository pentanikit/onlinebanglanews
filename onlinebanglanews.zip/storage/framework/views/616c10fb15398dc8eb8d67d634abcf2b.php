      <div class="widget" style="width: 300px;">
        <h3>সর্বশেষ</h3>
        <ul class="list">
            <?php $__empty_1 = true; $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li><a href="<?php echo e(route('singleNews', $item->slug)); ?>"><?php echo e($item->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <p>এই ক্যাটাগরিতে কোনো খবর পাওয়া যায়নি।</p>
            <?php endif; ?>
          
        
        </ul>
      </div><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/latest-news.blade.php ENDPATH**/ ?>