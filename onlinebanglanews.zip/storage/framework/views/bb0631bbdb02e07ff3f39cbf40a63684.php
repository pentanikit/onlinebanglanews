

          <div class="section-title">
              <h2><?php echo e($catTitle); ?></h2>
              <a href="#">সব খবর »</a>
          </div>
      <div class="news-grid">
          <?php $__empty_1 = true; $__currentLoopData = $categoriesNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <a href="<?php echo e(route('singleNews', $item->slug)); ?>">

                  <article class="news-card" style="height: 480px;">
                       <img src="<?php echo e(asset('storage') . '/' . $item->featuredImage->file_path ?? ''); ?>"
                          style="width: 100%; height: 220px; object-fit:fill;" alt="<?php echo e($item->title ?? 'Lead News'); ?>">
                      <h3><?php echo e($item->title); ?></h3>
                      <p class="meta"><?php echo e($item->author->name); ?></p>
                      <p><?php echo e($item->excerpt); ?></p>
                  </article>
              </a>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p>এই ক্যাটাগরিতে কোনো খবর পাওয়া যায়নি।</p>
          <?php endif; ?>

      </div>
<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/category-news.blade.php ENDPATH**/ ?>