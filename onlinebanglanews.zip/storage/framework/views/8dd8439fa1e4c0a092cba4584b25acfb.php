
<?php $__env->startSection('pages'); ?>
     <div class="container main-layout">
         <?php if (isset($component)) { $__componentOriginal85146347223c504b33dd47efc73905fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal85146347223c504b33dd47efc73905fd = $attributes; } ?>
<?php $component = App\View\Components\Frontend\SingleNews::resolve(['post' => $post] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.single-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\SingleNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal85146347223c504b33dd47efc73905fd)): ?>
<?php $attributes = $__attributesOriginal85146347223c504b33dd47efc73905fd; ?>
<?php unset($__attributesOriginal85146347223c504b33dd47efc73905fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85146347223c504b33dd47efc73905fd)): ?>
<?php $component = $__componentOriginal85146347223c504b33dd47efc73905fd; ?>
<?php unset($__componentOriginal85146347223c504b33dd47efc73905fd); ?>
<?php endif; ?>
     </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/frontend/singlenews.blade.php ENDPATH**/ ?>