        <!-- Comments -->
        <section id="view-comments" class="view d-none">
          <div class="card">
            <div class="card-header"><h5 class="mb-0">কমেন্ট</h5></div>
            <div class="card-body card-table">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>পোস্ট</th>
                    <th>কমেন্ট</th>
                    <th>অবস্থা</th>
                    <th class="text-end">একশন</th>
                  </tr>
                </thead>
                <tbody id="commentsTbody"></tbody>
              </table>
            </div>
          </div>
        </section><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/backend/comments.blade.php ENDPATH**/ ?>