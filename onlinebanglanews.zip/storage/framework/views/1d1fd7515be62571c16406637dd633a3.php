<?php if($breaking->isNotEmpty()): ?>

    <?php
        $lead = $breaking->first(); // প্রথম নিউজ
        $others = $breaking->skip(1); // বাকি সব নিউজ
    ?>

    
    <article class="lead-news">
        <a href="<?php echo e(route('singleNews', $lead->slug)); ?>">
            <img src="<?php echo e(asset('storage') . '/' . $lead->featuredImage->file_path ?? ''); ?>"
                style="width: 100%; height: auto; object-fit:cover;" alt="<?php echo e($lead->title ?? 'Lead News'); ?>">

            <h2><?php echo e($lead->title); ?></h2>

            <p class="meta">
                <?php echo e($lead->author->name ?? 'স্টাফ রিপোর্টার'); ?> |
                <?php echo e($lead->published_at?->format('d F Y')); ?>

            </p>

            <p class="excerpt">
                <?php echo e($lead->excerpt ?? Str::limit(strip_tags($lead->content), 150)); ?>

            </p>
        </a>

    </article>

    
    <?php if($others->isNotEmpty()): ?>
        <div class="news-grid">
            <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('singleNews', $item->slug)); ?>">
                 <article class="news-card" style="height: 440px;">
                    <img src="<?php echo e(asset('storage') . '/' . $item->featuredImage->file_path ?? ''); ?>"
                        style="width: 100%; height: auto; object-fit:cover;"
                        alt="<?php echo e($lead->title ?? 'Lead News'); ?>">
                    <h3><?php echo e($item->title); ?></h3>

                    <p class="meta">
                        <?php echo e($item->author->name ?? 'স্টাফ রিপোর্টার'); ?>

                    </p>

                    <p>
                        <?php echo e($item->excerpt ?? Str::limit(strip_tags($item->content), 120)); ?>

                    </p>
                </article>
            </a>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    
    <p>কোনো ব্রেকিং নিউজ পাওয়া যায়নি।</p>
<?php endif; ?>
<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/breaking-news.blade.php ENDPATH**/ ?>