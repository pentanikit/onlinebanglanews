<!-- Nav -->
<nav class="main-nav">
  <div class="container nav-inner">

    <?php $__empty_1 = true; $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php
          // Link বানানো
          if ($index === 0) {
              // প্রথম আইটেম = হোম
              $href = url('/'); // বা route('home') যদি থাকে
          } else {
              // বাকি আইটেম = ক্যাটাগরি
              $href = url('category/' . $item->slug); // নিজের রুট অনুযায়ী ঠিক করে নাও
          }

          // active ক্লাস নির্ধারণ
          if ($index === 0) {
              // হোম পেজে থাকলে প্রথম আইটেম active
              $isActive = request()->is('/') || request()->routeIs('home');
          } else {
              // ক্যাটাগরি পেজে থাকলে সেই ক্যাটাগরি active
              $isActive = request()->is('category/' . $item->slug);
          }
      ?>

      <a href="<?php echo e($href); ?>" class="<?php echo e($isActive ? 'active' : ''); ?>">
          <?php echo e($item->name); ?>

      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <a href="#">Not available</a>
    <?php endif; ?>

  </div>
</nav>





<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/navigation.blade.php ENDPATH**/ ?>