    <!-- Header -->
  <header class="header">
    <div class="container header-inner">
      <div class="logo">
        <h1> <img src="<?php echo e(asset('storage').'/'.$headerLogo[0]); ?>" alt="" srcset=""></h1>
        <p class="tagline">সত্য ও নির্ভরযোগ্য সংবাদ</p>
      </div>
      <div class="banner-ad">
        <span>728x90 AD</span>
      </div>
    </div>
  </header><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/header.blade.php ENDPATH**/ ?>