<?php $__env->startSection('pages'); ?>
      <!-- Main Layout -->
  <div class="container main-layout">
    <!-- Left/Main Column -->
    <main class="content">
      <!-- Lead News -->
      <?php if (isset($component)) { $__componentOriginal46bb229ff7d9554edce69b6e8562b094 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46bb229ff7d9554edce69b6e8562b094 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\BreakingNews::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.breaking-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\BreakingNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46bb229ff7d9554edce69b6e8562b094)): ?>
<?php $attributes = $__attributesOriginal46bb229ff7d9554edce69b6e8562b094; ?>
<?php unset($__attributesOriginal46bb229ff7d9554edce69b6e8562b094); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46bb229ff7d9554edce69b6e8562b094)): ?>
<?php $component = $__componentOriginal46bb229ff7d9554edce69b6e8562b094; ?>
<?php unset($__componentOriginal46bb229ff7d9554edce69b6e8562b094); ?>
<?php endif; ?>

      
      <?php if (isset($component)) { $__componentOriginal472a5b59cbd66af3bb8db53e42804136 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472a5b59cbd66af3bb8db53e42804136 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\CategoryNews::resolve(['slug' => 'বাংলাদেশ'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.category-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\CategoryNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472a5b59cbd66af3bb8db53e42804136)): ?>
<?php $attributes = $__attributesOriginal472a5b59cbd66af3bb8db53e42804136; ?>
<?php unset($__attributesOriginal472a5b59cbd66af3bb8db53e42804136); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472a5b59cbd66af3bb8db53e42804136)): ?>
<?php $component = $__componentOriginal472a5b59cbd66af3bb8db53e42804136; ?>
<?php unset($__componentOriginal472a5b59cbd66af3bb8db53e42804136); ?>
<?php endif; ?>
       <?php if (isset($component)) { $__componentOriginal3dcf83ed1665df564c8bea5699692075 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3dcf83ed1665df564c8bea5699692075 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\InternationalNews::resolve(['slug' => 'আন্তর্জাতিক'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.international-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\InternationalNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3dcf83ed1665df564c8bea5699692075)): ?>
<?php $attributes = $__attributesOriginal3dcf83ed1665df564c8bea5699692075; ?>
<?php unset($__attributesOriginal3dcf83ed1665df564c8bea5699692075); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3dcf83ed1665df564c8bea5699692075)): ?>
<?php $component = $__componentOriginal3dcf83ed1665df564c8bea5699692075; ?>
<?php unset($__componentOriginal3dcf83ed1665df564c8bea5699692075); ?>
<?php endif; ?>
     
    </main>

    <!-- Right Sidebar -->
    <aside class="sidebar">
      <?php if (isset($component)) { $__componentOriginal1694038806aa1acdffca9de32f4d7a2a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1694038806aa1acdffca9de32f4d7a2a = $attributes; } ?>
<?php $component = App\View\Components\Frontend\LatestNews::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.latest-news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\LatestNews::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1694038806aa1acdffca9de32f4d7a2a)): ?>
<?php $attributes = $__attributesOriginal1694038806aa1acdffca9de32f4d7a2a; ?>
<?php unset($__attributesOriginal1694038806aa1acdffca9de32f4d7a2a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1694038806aa1acdffca9de32f4d7a2a)): ?>
<?php $component = $__componentOriginal1694038806aa1acdffca9de32f4d7a2a; ?>
<?php unset($__componentOriginal1694038806aa1acdffca9de32f4d7a2a); ?>
<?php endif; ?>

      <div class="widget" style="width: 300px;">
        <h3>জনপ্রিয়</h3>
        <ul class="list">
          <li><a href="#">দামের মধ্যে যেসব স্মার্টফোন বাজারে</a></li>
          <li><a href="#">শীতে ত্বকের যত্ন নেবেন যেভাবে</a></li>
          <li><a href="#">বাংলাদেশ দলের বিশ্বকাপ বিশ্লেষণ</a></li>
        </ul>
      </div>

      <div class="widget ad-widget" style="width: 300px; height: 250px;">
        <span>300x250 AD</span>
      </div>
      <div class="widget ad-widget" style="width: 300px; height: 250px;">
        <span>300x250 AD</span>
      </div>
      <div class="widget ad-widget" style="width: 300px; height: 250px;">
        <span>300x250 AD</span>
      </div>
      <div class="widget ad-widget" style="width: 300px; height: 250px;">
        <span>300x250 AD</span>
      </div>
    </aside>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/frontend/home.blade.php ENDPATH**/ ?>