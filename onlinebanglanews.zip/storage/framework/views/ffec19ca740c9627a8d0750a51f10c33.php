    <main class="content">

      
            
      <article class="single-post">
        <h1><?php echo e($singlePost->title); ?></h1>
        <p class="single-meta"><?php echo e($singlePost->author->name ?? 'স্টাফ রিপোর্টার'); ?></p>
        <img src="<?php echo e(asset('storage').'/'.$singlePost->featuredImage->file_path); ?>" style="max-width: 600px; height:400px;" class="single-cover" alt="">

        <div class="single-body">
            <?php echo e($singlePost->excerpt); ?>

        </div>

        <!-- Tags / category -->
      <div class="single-tags">
          <span>ট্যাগ:</span>

          <?php if(!empty($singlePost->tags)): ?>
              <?php $__currentLoopData = explode(',', $singlePost->tags[0]->name); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $tag = trim($tag); ?>

                  <?php if($tag !== ''): ?>
                     
                      <a href="#"><?php echo e($tag); ?></a>

                      
                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </div>

      </article>


    </main>
        
<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/single-news.blade.php ENDPATH**/ ?>