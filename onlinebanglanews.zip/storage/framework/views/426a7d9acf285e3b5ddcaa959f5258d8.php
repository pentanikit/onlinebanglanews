 <?php if($international->isNotEmpty()): ?>
     <?php
         $lead = $international->first(); // প্রথম নিউজ
         $second = $international[1];
         $others = $international->skip(2); // বাকি সব নিউজ
     ?>

     <!-- Page Title -->
     
         <div class="section-title">
             <h2><?php echo e($catTitle); ?></h2>
             <a href="#">সব খবর »</a>
         </div>
     

     <!-- Main Layout -->
     <div class="main-layout">
         <main class="content">
             <!-- Featured of this category -->


             <article class="lead-news">

                 <img src="<?php echo e(asset('storage') . '/' . $lead->featuredImage->file_path); ?>"
                         style="width: 100%; height: 240px;" alt="" srcset="">
                     <h2><?php echo e($lead->title); ?></h2>
                    
                 

                 <p class="meta"><?php echo e($lead->author->name); ?> | ১১ নভেম্বর ২০২৫</p>
                 <p class="excerpt">
                   <?php echo e($lead->excerpt); ?>

                 </p>
             </article>





             <!-- Category listing -->
             <div class="category-list">
               
                    <article class="cat-item" >
                         <img src="<?php echo e(asset('storage') . '/' . $second->featuredImage->file_path); ?>"
                            style="width: 100%; height: 240px;" alt="" srcset="">
                        <h3><a href="<?php echo e(route('singleNews', $second->slug)); ?>"><?php echo e($second->title); ?></a></h3>
                        <p class="meta"><?php echo e($second->author->name); ?> | ১১ নভেম্বর ২০২৫</p>
                        <p><?php echo e($second->excerpt); ?></p>
                    </article>
              
                    
               

               
             </div>



         </main>

    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="widget">
        <h3>আরো দেখুন </h3>
        <ul class="list">
            <?php $__empty_1 = true; $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <li><a href="<?php echo e(route('singleNews', $item->slug)); ?>"><?php echo e($item->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No more found</p>
            <?php endif; ?>
         
         
        </ul>
      </div>
      <div class="widget ad-widget">
        <span>300x250 AD</span>
      </div>
    </aside>
     </div>
 <?php else: ?>
     
     <p>কোনো নিউজ পাওয়া যায়নি।</p>
 <?php endif; ?>
<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/international-news.blade.php ENDPATH**/ ?>