<?php
    use Illuminate\Support\Str;
?>

<?php if($categoriesNews2->isNotEmpty()): ?>

    <?php
        $first = $categoriesNews2->first();   // প্রথম নিউজ
        $others = $categoriesNews2->skip(1);  // বাকি সব নিউজ
    ?>

    
    <a href="<?php echo e(route('singleNews', $first->slug)); ?>">
        <article class="lead-news">
            <?php
                $firstImage = optional($first->featuredImage)->file_path;
            ?>

            <?php if($firstImage): ?>
                <img src="<?php echo e(asset('storage/' . $firstImage)); ?>"
                     style="width: 100%; height: auto; object-fit:cover;"
                     alt="<?php echo e($first->title ?? 'Lead News'); ?>">
            <?php endif; ?>

            <h2><?php echo e($first->title); ?></h2>

            <p class="meta">
                <?php echo e($first->author->name ?? 'স্টাফ রিপোর্টার'); ?> |
                <?php echo e(optional($first->published_at)->format('d F Y')); ?>

            </p>

            <p class="excerpt">
                <?php echo e($first->excerpt ?? Str::limit(strip_tags($first->content), 150)); ?>

            </p>
        </article>
    </a>

    
    <?php if($others->isNotEmpty()): ?>
        <div class="news-grid">
            <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('singleNews', $item->slug)); ?>">
                    <article class="news-card">

                        <?php
                            $itemImage = optional($item->featuredImage)->file_path;
                        ?>

                        <?php if($itemImage): ?>
                            <img src="<?php echo e(asset('storage/' . $itemImage)); ?>"
                                 style="max-width: 240px; height: auto; object-fit:cover;"
                                 alt="<?php echo e($item->title ?? 'News'); ?>">
                        <?php endif; ?>

                        <h3><?php echo e($item->title); ?></h3>

                        <p class="meta">
                            <?php echo e($item->author->name ?? 'স্টাফ রিপোর্টার'); ?>

                        </p>

                        <p>
                            <?php echo e($item->excerpt ?? Str::limit(strip_tags($item->content), 120)); ?>

                        </p>
                    </article>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <p>কোনো নিউজ পাওয়া যায়নি।</p>
<?php endif; ?>
<?php /**PATH C:\Users\Pentanik IT\Desktop\onlinebanglanews\resources\views/components/frontend/category-news2.blade.php ENDPATH**/ ?>